n="qweyupcsfoghjkldezxvbintma"
str="ativedoc"
s=''
for i in n:
    n.index(  
    
    
    