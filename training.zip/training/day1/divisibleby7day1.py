l=300
u=400
count=0
for i in range(l,u+1):
    if i%7==0:
        count=count+1
print(count)