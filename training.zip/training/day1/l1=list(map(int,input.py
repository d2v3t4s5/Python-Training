l1=list(map(int,input().split()))
l2=list(map(int,input().split()))
l3=[]
i,j=0,0
while(i<len(l1) and j<len(l2)):
    if 