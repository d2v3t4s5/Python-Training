n=int(input())
while(n>0):
    sum=0
    x=n%10
    sum=sum+x
    n=n//10
print(sum)
    
