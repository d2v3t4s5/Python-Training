l=[1,2,3,4]
if len(l)%2==0:
    print("yes")
else:
    print("no")
           
           
           
           
           
