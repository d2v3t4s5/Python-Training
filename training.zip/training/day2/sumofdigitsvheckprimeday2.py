'''def iss_prime(num):
    for i in range(2,(n//2)+1):
        if n%i==0:
            return False
        else:
            return True
def add_digits(num):
    while num>=10:
        sum=0
        while num>0:
            sum=sum+n%10
            num=num//10
        num=sum
    return num
          
n=int(input())
d_s=add_digits(n)
if iss_prime(d_s):
    print(n)
else:
    n=n+1'''
    
    
    
def adds(n):
    s=0
    while(n):
        s=s+n%10
        n=n//10
    return s  
def pnp(n):
    if(n in [2,3,5,7]):
        return m
    else:
        return m+1
n=int(input())
m=n
if(n<10):7-=
    print(pnp(n))
else:
    while(1):
        n=adds(n)
        if(n<10):
            break
    print(pnp(n))
    
    
            

    

    

    
    
    
    
    
    
    
    

